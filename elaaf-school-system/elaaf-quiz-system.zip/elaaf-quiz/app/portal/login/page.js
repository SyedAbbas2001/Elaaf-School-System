"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const res = await signIn("credentials", { email, password, redirect: false });
    setBusy(false);
    if (res?.error) return setError("Email ya password galat hai");
    router.push("/portal/dashboard");
    router.refresh();
  }

  return (
    <div className="pt-center">
      <form className="pt-card pt-login" onSubmit={onSubmit}>
        <h1>Teacher login</h1>
        <div className="pt-field">
          <label htmlFor="email">Email</label>
          <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div className="pt-field">
          <label htmlFor="password">Password</label>
          <input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div>
        {error && <p className="pt-error">{error}</p>}
        <button className="pt-btn" disabled={busy}>{busy ? "Login ho raha hai..." : "Log in"}</button>
      </form>
    </div>
  );
}
