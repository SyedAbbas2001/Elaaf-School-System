"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { CLASSES, SUBJECTS } from "@/lib/constants";

export default function NewQuizPage() {
  const router = useRouter();
  const [f, setF] = useState({ title: "", className: CLASSES[0], subject: SUBJECTS[0], timeLimitMin: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function onSubmit(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const res = await fetch("/api/quizzes", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f) });
    const data = await res.json();
    if (!res.ok) {
      setBusy(false);
      return setError(data.error || "Quiz nahi bana");
    }
    router.push(`/portal/dashboard/quizzes/${data.id}`);
  }

  return (
    <form className="pt-card" onSubmit={onSubmit} style={{ marginLeft: 0 }}>
      <h1>Naya quiz</h1>
      <div className="pt-field">
        <label htmlFor="title">Quiz ka title</label>
        <input id="title" value={f.title} onChange={set("title")} placeholder="Jaise: Chapter 3 test" required />
      </div>
      <div className="pt-field">
        <label htmlFor="cls">Class</label>
        <select id="cls" value={f.className} onChange={set("className")}>{CLASSES.map((c) => <option key={c}>{c}</option>)}</select>
      </div>
      <div className="pt-field">
        <label htmlFor="sub">Subject</label>
        <select id="sub" value={f.subject} onChange={set("subject")}>{SUBJECTS.map((s) => <option key={s}>{s}</option>)}</select>
      </div>
      <div className="pt-field">
        <label htmlFor="time">Time limit (minute, khali = koi limit nahi)</label>
        <input id="time" type="number" min="0" value={f.timeLimitMin} onChange={set("timeLimitMin")} />
      </div>
      {error && <p className="pt-error">{error}</p>}
      <button className="pt-btn" disabled={busy}>{busy ? "Ban raha hai..." : "Quiz banayein"}</button>
    </form>
  );
}
