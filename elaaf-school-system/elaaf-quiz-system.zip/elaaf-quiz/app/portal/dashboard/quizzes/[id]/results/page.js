import Link from "next/link";
import { notFound } from "next/navigation";
import { getOwnedQuiz } from "@/lib/quizAccess";
import Attempt from "@/lib/models/Attempt";

export const dynamic = "force-dynamic";

export default async function ResultsPage({ params }) {
  const { id } = await params;
  const r = await getOwnedQuiz(id);
  if (r.error) notFound();
  const quiz = r.quiz;
  const attempts = await Attempt.find({ quiz: quiz._id }).sort({ createdAt: -1 }).lean();

  return (
    <>
      <h1>{quiz.title}: results</h1>
      <p className="pt-muted">{quiz.className} · {quiz.subject} · {attempts.length} students ne diya</p>
      <div className="pt-row" style={{ margin: "12px 0 16px" }}>
        <a className="pt-btn" href={`/api/quizzes/${id}/export`}>CSV download karein</a>
        <Link className="pt-btn alt" href={`/portal/dashboard/quizzes/${id}`}>Quiz edit karein</Link>
      </div>
      {attempts.length === 0 ? (
        <div className="pt-card"><p className="pt-muted">Abhi kisi student ne yeh quiz nahi diya.</p></div>
      ) : (
        <div className="pt-table-wrap">
          <table className="pt-table">
            <thead><tr><th>Roll No</th><th>Name</th><th>Class</th><th>Score</th><th>Date</th></tr></thead>
            <tbody>
              {attempts.map((a) => (
                <tr key={String(a._id)}>
                  <td>{a.rollNo}</td>
                  <td>{a.studentName}</td>
                  <td>{a.className}</td>
                  <td>{a.score} / {a.total}</td>
                  <td>{new Date(a.createdAt).toLocaleString("en-GB", { timeZone: "Asia/Karachi" })}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
