import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { connectDB } from "@/lib/mongodb";
import Quiz from "@/lib/models/Quiz";
import { CLASSES, SUBJECTS } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function DashboardPage({ searchParams }) {
  const sp = await searchParams;
  const session = await getServerSession(authOptions);
  await connectDB();

  const filter = session.user.role === "admin" ? {} : { teacher: session.user.id };
  if (sp?.className) filter.className = sp.className;
  if (sp?.subject) filter.subject = sp.subject;
  const quizzes = await Quiz.find(filter).sort({ createdAt: -1 }).lean();

  return (
    <>
      <h1>Mere quizzes</h1>
      <form className="pt-filters" method="GET">
        <select name="className" defaultValue={sp?.className || ""} aria-label="Class">
          <option value="">Saari classes</option>
          {CLASSES.map((c) => <option key={c}>{c}</option>)}
        </select>
        <select name="subject" defaultValue={sp?.subject || ""} aria-label="Subject">
          <option value="">Saare subjects</option>
          {SUBJECTS.map((s) => <option key={s}>{s}</option>)}
        </select>
        <button className="pt-btn alt">Filter lagayein</button>
        <Link className="pt-btn" href="/portal/dashboard/quizzes/new">Naya quiz</Link>
      </form>

      {quizzes.length === 0 ? (
        <div className="pt-card"><p className="pt-muted">Abhi koi quiz nahi hai. &quot;Naya quiz&quot; se pehla quiz banayein.</p></div>
      ) : (
        <div className="pt-table-wrap">
          <table className="pt-table">
            <thead>
              <tr><th>Title</th><th>Class</th><th>Subject</th><th>Questions</th><th>Status</th><th>Code</th><th></th></tr>
            </thead>
            <tbody>
              {quizzes.map((q) => (
                <tr key={String(q._id)}>
                  <td>{q.title}</td>
                  <td>{q.className}</td>
                  <td>{q.subject}</td>
                  <td>{q.questions.length}</td>
                  <td><span className={`pt-badge ${q.status === "published" ? "live" : ""}`}>{q.status === "published" ? "Published" : "Draft"}</span></td>
                  <td>{q.code}</td>
                  <td>
                    <Link href={`/portal/dashboard/quizzes/${q._id}`}>Edit</Link>
                    <Link href={`/portal/dashboard/quizzes/${q._id}/results`}>Results</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
