import Link from "next/link";
import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import SignOutButton from "@/components/portal/SignOutButton";

export default async function DashboardLayout({ children }) {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/portal/login");

  return (
    <div className="pt-shell">
      <aside className="pt-side">
        <h2>Elaaf Portal</h2>
        <p className="pt-who">{session.user.name}</p>
        <Link href="/portal/dashboard">Mere quizzes</Link>
        <Link href="/portal/dashboard/quizzes/new">Naya quiz</Link>
        <SignOutButton />
      </aside>
      <main className="pt-main">{children}</main>
    </div>
  );
}
