import { NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";
import Quiz from "@/lib/models/Quiz";
import Attempt from "@/lib/models/Attempt";

// Marking sirf server pe hoti hai, sahi jawab student ke browser tak kabhi nahi jaate
export async function POST(req) {
  const { code, studentName, rollNo, className, answers } = await req.json();
  if (!studentName?.trim() || !rollNo?.trim()) {
    return NextResponse.json({ error: "Naam aur roll number likhein" }, { status: 400 });
  }
  await connectDB();
  const quiz = await Quiz.findOne({ code: String(code).toUpperCase(), status: "published" });
  if (!quiz) return NextResponse.json({ error: "Quiz nahi mila ya band hai" }, { status: 404 });

  const roll = rollNo.trim();
  const cls = (className || quiz.className).trim();
  const dup = await Attempt.findOne({ quiz: quiz._id, rollNo: roll, className: cls });
  if (dup) return NextResponse.json({ error: "Is roll number se yeh quiz pehle de diya gaya hai" }, { status: 409 });

  let score = 0;
  let total = 0;
  quiz.questions.forEach((q, i) => {
    total += q.marks;
    if (answers?.[i] === q.correctIndex) score += q.marks;
  });

  await Attempt.create({
    quiz: quiz._id,
    studentName: studentName.trim(),
    rollNo: roll,
    className: cls,
    answers: (answers || []).map((a) => (typeof a === "number" ? a : -1)),
    score,
    total,
  });
  return NextResponse.json({ score, total });
}
