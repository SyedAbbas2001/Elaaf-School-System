"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

const blank = () => ({ text: "", options: ["", "", "", ""], correctIndex: 0, marks: 1 });

export default function QuizEditor({ quiz }) {
  const router = useRouter();
  const [qs, setQs] = useState(quiz.questions.length ? quiz.questions : [blank()]);
  const [status, setStatus] = useState(quiz.status);
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [busy, setBusy] = useState(false);

  const upd = (i, patch) => setQs(qs.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  const updOpt = (i, k, v) => upd(i, { options: qs[i].options.map((o, j) => (j === k ? v : o)) });

  async function save(nextStatus = status) {
    setBusy(true);
    setMsg({ type: "", text: "" });
    const res = await fetch(`/api/quizzes/${quiz.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ questions: qs, status: nextStatus }),
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) return setMsg({ type: "error", text: data.error || "Save nahi hua" });
    setStatus(nextStatus);
    setMsg({ type: "ok", text: nextStatus === "published" ? "Published. Ab link students ko bhej dein." : "Save ho gaya." });
  }

  async function remove() {
    if (!confirm("Yeh quiz aur is ke saare results hamesha ke liye delete ho jayenge. Pakka?")) return;
    const res = await fetch(`/api/quizzes/${quiz.id}`, { method: "DELETE" });
    if (res.ok) {
      router.push("/portal/dashboard");
      router.refresh();
    }
  }

  async function copyLink() {
    await navigator.clipboard.writeText(`${window.location.origin}/quiz/${quiz.code}`);
    setMsg({ type: "ok", text: "Link copy ho gaya." });
  }

  return (
    <>
      <h1>{quiz.title}</h1>
      <p className="pt-muted">
        {quiz.className} · {quiz.subject} · {status === "published" ? "Published" : "Draft"} · Code: <strong>{quiz.code}</strong>
      </p>

      <div style={{ margin: "16px 0" }}>
        {qs.map((q, i) => (
          <div className="pt-q" key={i}>
            <div className="pt-q-head">
              <span>Question {i + 1}</span>
              {qs.length > 1 && (
                <button type="button" className="pt-btn danger" onClick={() => setQs(qs.filter((_, j) => j !== i))}>Hatayein</button>
              )}
            </div>
            <div className="pt-field">
              <input value={q.text} onChange={(e) => upd(i, { text: e.target.value })} placeholder="Question likhein" aria-label={`Question ${i + 1}`} />
            </div>
            {q.options.map((o, k) => (
              <div className="pt-opt" key={k}>
                <input type="radio" name={`correct-${i}`} checked={q.correctIndex === k} onChange={() => upd(i, { correctIndex: k })} aria-label={`Option ${k + 1} sahi jawab hai`} />
                <input type="text" value={o} onChange={(e) => updOpt(i, k, e.target.value)} placeholder={`Option ${k + 1}`} />
              </div>
            ))}
            <p className="pt-muted" style={{ margin: "4px 0 0", fontSize: ".85rem" }}>Sahi jawab ke saamne wala button select karein.</p>
          </div>
        ))}
      </div>

      <div className="pt-row">
        <button type="button" className="pt-btn alt" onClick={() => setQs([...qs, blank()])}>Question add karein</button>
        <button type="button" className="pt-btn" disabled={busy} onClick={() => save()}>Save karein</button>
        {status === "draft" ? (
          <button type="button" className="pt-btn" disabled={busy} onClick={() => save("published")}>Publish karein</button>
        ) : (
          <>
            <button type="button" className="pt-btn alt" disabled={busy} onClick={() => save("draft")}>Draft me wapis</button>
            <button type="button" className="pt-btn alt" onClick={copyLink}>Student link copy karein</button>
          </>
        )}
        <button type="button" className="pt-btn danger" onClick={remove}>Quiz delete karein</button>
      </div>
      {msg.text && <p className={msg.type === "error" ? "pt-error" : "pt-ok"}>{msg.text}</p>}
      {status === "published" && <p className="pt-muted">Student link: /quiz/{quiz.code}</p>}
    </>
  );
}
