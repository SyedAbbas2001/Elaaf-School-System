"use client";
import { useEffect, useRef, useState } from "react";
import "@/app/portal/portal.css";

export default function QuizTaker({ code, quiz }) {
  const [step, setStep] = useState("info"); // info | quiz | done
  const [info, setInfo] = useState({ studentName: "", rollNo: "", className: quiz.className });
  const [answers, setAnswers] = useState(Array(quiz.questions.length).fill(null));
  const [left, setLeft] = useState(quiz.timeLimitMin * 60);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const submitted = useRef(false);
  const latest = useRef();

  async function submit() {
    if (submitted.current) return;
    submitted.current = true;
    setBusy(true);
    const res = await fetch("/api/quiz/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, ...info, answers }),
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      submitted.current = false;
      setError(data.error || "Jawab jama nahi hue, dobara koshish karein");
      if (res.status === 409) setStep("info");
      return;
    }
    setResult(data);
    setStep("done");
  }
  latest.current = submit;

  useEffect(() => {
    if (step !== "quiz" || !quiz.timeLimitMin) return;
    const t = setInterval(() => setLeft((l) => l - 1), 1000);
    return () => clearInterval(t);
  }, [step, quiz.timeLimitMin]);

  useEffect(() => {
    if (step === "quiz" && quiz.timeLimitMin && left <= 0) latest.current();
  }, [left, step, quiz.timeLimitMin]);

  function start(e) {
    e.preventDefault();
    if (!info.studentName.trim() || !info.rollNo.trim()) return setError("Naam aur roll number likhein");
    setError("");
    setStep("quiz");
  }

  const mm = String(Math.max(0, Math.floor(left / 60))).padStart(2, "0");
  const ss = String(Math.max(0, left % 60)).padStart(2, "0");

  return (
    <div className="pt-quiz">
      {step === "info" && (
        <form className="pt-card" onSubmit={start}>
          <h1>{quiz.title}</h1>
          <p className="pt-muted">{quiz.className} · {quiz.subject} · {quiz.questions.length} questions{quiz.timeLimitMin ? ` · ${quiz.timeLimitMin} minute` : ""}</p>
          <div className="pt-field">
            <label htmlFor="n">Aap ka naam</label>
            <input id="n" value={info.studentName} onChange={(e) => setInfo({ ...info, studentName: e.target.value })} required />
          </div>
          <div className="pt-field">
            <label htmlFor="r">Roll number</label>
            <input id="r" value={info.rollNo} onChange={(e) => setInfo({ ...info, rollNo: e.target.value })} required />
          </div>
          {error && <p className="pt-error">{error}</p>}
          <button className="pt-btn">Quiz shuru karein</button>
        </form>
      )}

      {step === "quiz" && (
        <div style={{ maxWidth: 760, margin: "0 auto" }}>
          {quiz.timeLimitMin > 0 && <div className="pt-timer" role="timer">{mm}:{ss}</div>}
          <h1>{quiz.title}</h1>
          {quiz.questions.map((q, i) => (
            <div className="pt-card" key={i}>
              <p style={{ fontWeight: 600, marginTop: 0 }}>{i + 1}. {q.text}</p>
              {q.options.map((o, k) => (
                <label className="pt-choice" key={k}>
                  <input type="radio" name={`q${i}`} checked={answers[i] === k} onChange={() => setAnswers(answers.map((a, j) => (j === i ? k : a)))} />
                  <span>{o}</span>
                </label>
              ))}
            </div>
          ))}
          {error && <p className="pt-error">{error}</p>}
          <button className="pt-btn" disabled={busy} onClick={submit}>{busy ? "Jama ho raha hai..." : "Jawab jama karein"}</button>
        </div>
      )}

      {step === "done" && result && (
        <div className="pt-card" style={{ textAlign: "center" }}>
          <h1>Shukriya, {info.studentName}</h1>
          <p className="pt-muted">Aap ke jawab jama ho gaye.</p>
          <p className="pt-score">{result.score} / {result.total}</p>
        </div>
      )}
    </div>
  );
}
