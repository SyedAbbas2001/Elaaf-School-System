# Elaaf Quiz System: setup

1. npm i mongoose next-auth@4 bcryptjs
2. .env.local me: MONGODB_URI, NEXTAUTH_SECRET, NEXTAUTH_URL
3. Is folder ki files apne project me copy karein (same folder structure)
4. Pehla teacher banayein:
   node --env-file=.env.local scripts/create-teacher.mjs "Naam" email password admin
5. npm run dev, phir /portal/login
